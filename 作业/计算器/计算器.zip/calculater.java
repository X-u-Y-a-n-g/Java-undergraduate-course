package calculater;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;
import javax.swing.*;

public class calculater extends JFrame {
    // 创建面板
    private JPanel contentPane = new JPanel(new GridLayout(6, 4, 4, 4));
    // 创建按钮
    private JButton btn0 = new JButton("0");
    private JButton btn1 = new JButton("1");
    private JButton btn2 = new JButton("2");
    private JButton btn3 = new JButton("3");
    private JButton btn4 = new JButton("4");
    private JButton btn5 = new JButton("5");
    private JButton btn6 = new JButton("6");
    private JButton btn7 = new JButton("7");
    private JButton btn8 = new JButton("8");
    private JButton btn9 = new JButton("9");
    private JButton C = new JButton("C");
    private JButton equal = new JButton("=");
    private JButton add = new JButton("+");
    private JButton sub = new JButton("-");
    private JButton mul = new JButton("×");
    private JButton div = new JButton("÷");
    private JButton sign = new JButton("+/-");
    private JButton point = new JButton(".");
    private JButton CE = new JButton("CE");
    private JButton delivery = new JButton("%");
    private JButton reciprocal = new JButton("1/x");
    private JButton square = new JButton("x^2");
    private JButton sqrt = new JButton("√");
    private JButton del = new JButton("Del");
    // 创建显示框
    private JTextField text = new JTextField();
    String input = "";
    Font f = new Font("黑体", Font.BOLD, 38);
    Font s = new Font("宋体", Font.BOLD, 35);
    Color numColor = new Color(252, 252, 252);
    Color opColor = new Color(247, 247, 247);
    Color bgColor = new Color(242, 242, 242);

    // 设置按钮的边框、颜色、字体、背景、监听器、面板
    private void install(boolean border, Color col, JPanel contentPane, JButton btn, Font font, String actionCommand) {
        btn.setBorderPainted(border);
        btn.setBackground(col);
        btn.setFont(font);
        btn.setActionCommand(actionCommand); // 设置ActionCommand
        btn.addActionListener(new Model());
        contentPane.add(btn);
    }

    private void setText(JTextField text, Font s, Color color) {
        text.setBorder(null);
        text.setFont(s);
        text.setBackground(color);
        text.setColumns(28);
        text.setPreferredSize(new Dimension(0, 150));
    }

    public calculater() {
        setText(text, s, bgColor);
        JPanel topPane = new JPanel();
        topPane.setBackground(bgColor);
        topPane.setLayout(new BorderLayout());
        topPane.add(text, BorderLayout.CENTER);

        add(topPane, BorderLayout.NORTH);
        add(contentPane, BorderLayout.CENTER);

        setTitle("计算器");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450,650 );
        setLocationRelativeTo(null);

        install(false, opColor, contentPane, delivery, s, "%");
        install(false, opColor, contentPane, CE, s, "CE");
        install(false, opColor, contentPane, C, s, "C");
        install(false, opColor, contentPane, del, s, "Del");
        install(false, opColor, contentPane, reciprocal, s, "1/x");
        install(false, opColor, contentPane, square, s, "x^2");
        install(false, opColor, contentPane, sqrt, s, "√");
        install(false, opColor, contentPane, div, s, "÷");
        install(false, numColor, contentPane, btn7, f, "7");
        install(false, numColor, contentPane, btn8, f, "8");
        install(false, numColor, contentPane, btn9, f, "9");
        install(false, opColor, contentPane, mul, s, "×");
        install(false, numColor, contentPane, btn4, f, "4");
        install(false, numColor, contentPane, btn5, f, "5");
        install(false, numColor, contentPane, btn6, f, "6");
        install(false, opColor, contentPane, sub, s, "-");
        install(false, numColor, contentPane, btn1, f, "1");
        install(false, numColor, contentPane, btn2, f, "2");
        install(false, numColor, contentPane, btn3, f, "3");
        install(false, opColor, contentPane, add, s, "+");
        install(false, numColor, contentPane, sign, f, "+/-");
        install(false, numColor, contentPane, btn0, f, "0");
        install(false, numColor, contentPane, point, f, ".");
        install(false, opColor, contentPane, equal, s, "=");
    }

    private class Model implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            if ("0123456789.".contains(command)) {
                input += command;
                text.setText(input);
            } else if (command.equals("C")) {
                input = "";
                text.setText("");
            } else if (command.equals("CE")) {
                input = "";
                text.setText("");
            } else if (command.equals("Del")) {
                input = input.isEmpty() ? "" : input.substring(0, input.length() - 1);
                text.setText(input);
            } else if (command.equals("=")) {
                try {
                    text.setText(String.valueOf(evaluateExpression(input)));
                    input = text.getText();
                } catch (Exception ex) {
                    text.setText("Error");
                }
            } else if (command.equals("x^2")) {
                input = String.valueOf(Math.pow(Double.parseDouble(input), 2));
                text.setText(input);
            } else if (command.equals("√")) {
                input = String.valueOf(Math.sqrt(Double.parseDouble(input)));
                text.setText(input);
            } else if (command.equals("1/x")) {
                input = String.valueOf(1 / Double.parseDouble(input));
                text.setText(input);
            } else if (command.equals("%")) {
                input = String.valueOf(Double.parseDouble(input) / 100);
                text.setText(input);
            } else if (command.equals("+/-")) {
                input = String.valueOf(-Double.parseDouble(input));
                text.setText(input);
            } else {
                input += " " + command + " ";
                text.setText(input);
            }
        }
    }

    private double evaluateExpression(String expression) {
        String[] tokens = expression.split(" ");
        Stack<Double> values = new Stack<>();
        Stack<String> operators = new Stack<>();

        for (String token : tokens) {
            if (token.matches("[0-9.]+")) {
                values.push(Double.parseDouble(token));
            } else if (token.equals("+") || token.equals("-") || token.equals("×") || token.equals("÷")) {
                while (!operators.isEmpty() && precedence(token) <= precedence(operators.peek())) {
                    values.push(applyOperator(operators.pop(), values.pop(), values.pop()));
                }
                operators.push(token);
            }
        }

        while (!operators.isEmpty()) {
            values.push(applyOperator(operators.pop(), values.pop(), values.pop()));
        }

        return values.pop();
    }

    private int precedence(String op) {
        if (op.equals("+") || op.equals("-"))
            return 1;
        if (op.equals("×") || op.equals("÷"))
            return 2;
        return 0;
    }

    private double applyOperator(String op, double b, double a) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "×": return a * b;
            case "÷": return a / b;
            default: return 0;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            calculater frame = new calculater();
            frame.setVisible(true);
        });
    }
}
