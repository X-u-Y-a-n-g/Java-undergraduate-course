package HuaBan;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;

//组合框下拉选项是面板类型
class ColorCell extends JPanel {
	public Color cellColor;
	private JPanel colorLabel;
	private JLabel colorNameLabel;
	private String colorName;

	public ColorCell() {

	};

	public ColorCell(Color color, String name) {
		this.cellColor = color;
		this.colorName = name;
		colorLabel = new JPanel();
		colorLabel.setBackground(color);
		colorNameLabel = new JLabel(name);
		colorNameLabel.setForeground(color);
		colorLabel.setPreferredSize(new Dimension(40, 30));

		setLayout(new FlowLayout(FlowLayout.LEFT, 2, 0));
		add(colorLabel);
		add(colorNameLabel);
	}

	public Color getCellColor() {
		return cellColor;
	}

	public void setCellColor(Color cellColor) {
		this.cellColor = cellColor;
	}

	public String getColorName() {
		return colorName;
	}

	public void setColorName(String colorName) {
		this.colorName = colorName;
	}
}