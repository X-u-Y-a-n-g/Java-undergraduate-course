package HuaBan;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;

public class WestP extends JPanel implements ActionListener {
	ImageIcon icon1 = new ImageIcon("D:\\eclipse_workspace\\MyPainter\\src\\HuaBan\\直线.png");
	ImageIcon icon2 = new ImageIcon("D:\\eclipse_workspace\\MyPainter\\src\\HuaBan\\圆.png");
	ImageIcon icon3 = new ImageIcon("D:\\eclipse_workspace\\MyPainter\\src\\HuaBan\\正方形.png");
	ImageIcon icon4 = new ImageIcon("D:\\eclipse_workspace\\MyPainter\\src\\HuaBan\\椭圆.png");
	ImageIcon icon5 = new ImageIcon("D:\\eclipse_workspace\\MyPainter\\src\\HuaBan\\矩形.png");
	ImageIcon icon6 = new ImageIcon("D:\\eclipse_workspace\\MyPainter\\src\\HuaBan\\文本.png");

	// 左侧6个开关按钮，控制要绘制什么图形
	JToggleButton btn1 = new JToggleButton(icon1);
	JToggleButton btn2 = new JToggleButton(icon2);
	JToggleButton btn3 = new JToggleButton(icon3);
	JToggleButton btn4 = new JToggleButton(icon4);
	JToggleButton btn5 = new JToggleButton(icon5);
	JToggleButton btn6 = new JToggleButton(icon6);
	
	// 设置按钮上图标的缩放大小、为按钮添加监听器并设置背景色
	public void install(ImageIcon icon, WestP p, JToggleButton btn) {
		icon.setImage(icon.getImage().getScaledInstance(40, 40,
				Image.SCALE_DEFAULT));
		btn.addActionListener(p);
		btn.setBackground(new Color(255, 255, 255));
		p.add(btn);
	}

	public WestP() {
		// 设置网格布局
		this.setLayout(new GridLayout(9, 1));
		install(icon1, this, btn1);
		install(icon2, this, btn2);
		install(icon3, this, btn3);
		install(icon4, this, btn4);
		install(icon5, this, btn5);
		install(icon6, this, btn6);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btn1 || e.getSource() == btn2
				|| e.getSource() == btn3 || e.getSource() == btn4
				|| e.getSource() == btn5 || e.getSource() == btn6) {
			btn1.setSelected(false);
			btn2.setSelected(false);
			btn3.setSelected(false);
			btn4.setSelected(false);
			btn5.setSelected(false);
			btn6.setSelected(false);
			// 使选中的按钮生效，其他的按钮失效
			JToggleButton btn = (JToggleButton) e.getSource();
			btn.setSelected(true);
		}
	}

}