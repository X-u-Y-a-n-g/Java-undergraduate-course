package HuaBan;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.ListCellRenderer;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

class SpinnerN extends JPanel{
	SpinnerModel spinnerModel;
	JSpinner spinner;
	JLabel size;
	public SpinnerN() {
		spinnerModel = new SpinnerNumberModel(10, 0, 100, 1);
		spinner = new JSpinner(spinnerModel);
		size = new JLabel("Size");
		size.setFont(new Font("宋体", Font.BOLD, 25));
		JPanel temp1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp1.add(size);
		JPanel temp2 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		temp2.add(spinner);
		setLayout(new GridLayout(1, 2));
		add(temp1);
		add(temp2);
	}

	public int getValue(){
		return (int)spinner.getValue();
	}
}

public class NorthP extends JPanel{
	JComboBox shapecomboBox;
	JComboBox backcomboBox;
	JTextArea text;
	JCheckBox fill;
	boolean isfill;
	SpinnerN spin;
	public Color getUserColor;
	public Color getBackColor;
	public int size;
	Font s = new Font("宋体", Font.BOLD, 25);
	public NorthP() {
		shapecomboBox = createShapeBox();
		backcomboBox = createBackBox();
		text = new JTextArea(1, 37);
		text.setBorder(BorderFactory.createLineBorder(Color.black, 1));
		spin = new SpinnerN();
		fill = new JCheckBox("Fill the region");
		fill.setFont(s);
		JPanel temp1 = labelBox(makeLabel(s, "Shape Color"), shapecomboBox);
		JPanel temp2 = labelText(makeLabel(s, "Text"), text);
		JPanel temp3 = labelBox(makeLabel(s, "BackGround "), backcomboBox);
		JPanel temp4 = spinFill(spin, fill);
		GridLayout gridLayout=new GridLayout();
		this.setLayout(new GridLayout(2, 2));
		this.add(temp1);
		this.add(temp2);
		this.add(temp3);
		this.add(temp4);
		this.setBorder(BorderFactory.createLineBorder(Color.black, 1));
	}
	
	public JLabel makeLabel(Font s, String str){
		JLabel temp = new JLabel(str);
		temp.setFont(s);
		return temp;
	}
	
	public JPanel labelBox(JLabel label, JComboBox box){
		JPanel temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(label);
		temp.add(box);
		return temp;
	}
	
	public JPanel labelText(JLabel label, JTextArea text){
		JPanel temp = new JPanel(new FlowLayout(FlowLayout.LEFT));
		temp.add(label);
		temp.add(text);
		return temp;
	}
	
	public JPanel spinFill(SpinnerN k, JCheckBox theBox){
		theBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				trace();
			}
		});
		JPanel temp = new JPanel(new GridLayout(1,2));
		temp.add(k);
		temp.add(fill);
		return temp;
	}
	
	public void trace() {
		if (fill.isSelected())
			isfill = true;
		else
			isfill = false;
	}
	
	public JComboBox createShapeBox(){
		JComboBox Box = new JComboBox(new JPanel[] {
				new ColorCell(Color.red, "红色"),
				new ColorCell(Color.black, "黑色"),
				new ColorCell(Color.blue, "蓝色"),
				new ColorCell(Color.green, "绿色") });
		Box.setPreferredSize(new Dimension(80, 30));
		ListCellRenderer renderer = new PanelComboBoxCellRenderer();
		Box.setRenderer(renderer);
		Box.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					ColorCell mm = new ColorCell();
					mm = (ColorCell) e.getItem();
					getUserColor = mm.cellColor;
				}
			}
		});
		return Box;
	}
	
	public JComboBox createBackBox(){
		JComboBox Box = new JComboBox(new JPanel[] {
				new ColorCell(Color.red, "红色"),
				new ColorCell(Color.black, "黑色"),
				new ColorCell(Color.blue, "蓝色"),
				new ColorCell(Color.green, "绿色") });
		Box.setPreferredSize(new Dimension(80, 30));
		ListCellRenderer renderer = new PanelComboBoxCellRenderer();
		Box.setRenderer(renderer);
		Box.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					ColorCell mm = new ColorCell();
					mm = (ColorCell) e.getItem();
					getBackColor = mm.cellColor;
				}
			}
		});
		return Box;
	}
}