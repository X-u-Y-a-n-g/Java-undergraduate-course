package HuaBan;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Arrays;
import java.awt.event.ItemListener;
import java.awt.event.ActionListener;

//主面板
public class CenterP extends JPanel implements MouseListener,
		MouseMotionListener, ItemListener, ActionListener {
	// 用来储存每次绘画的坐标数组，颜色数组，图形数组，是否填充的数组
	private int[] x1 = new int[0];
	private int[] y1 = new int[0];
	private int[] x2 = new int[0];
	private int[] y2 = new int[0];
	private Color[] xycolor = new Color[0];
	private int[] xyshape = new int[0];
	private boolean[] fills = new boolean[0];

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	public WestP west = new WestP();
	public NorthP north = new NorthP();
	public SouthP south = new SouthP();
	public JPanel center = new JPanel();
	
	int startx=0,starty=0,endx=0,endy=0;
	public CenterP() {
		// 添加到主面板上
		this.setLayout(new BorderLayout());
		this.add(west, BorderLayout.WEST);
		this.add(north, BorderLayout.NORTH);
		this.add(center, BorderLayout.CENTER);
		this.add(south, BorderLayout.SOUTH);
		center.setBorder(BorderFactory.createLineBorder(Color.black, 1));
		// 注册当前组件鼠标监听
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}

	public void itemStateChanged(ItemEvent e) {
	}

	@Override
	// 绘画
	public void paint(Graphics g) {// 第一次显示的时候，由系统自动调用。

		super.paint(g);
		int j = 0;

		for (int i = 0; i < x1.length; i++, j++) {

			g.setColor(xycolor[j]);
			choiceShape(g, i, xyshape[j], fills[i]);
		}
		// 输出文字
		if (west.btn6.isSelected()) {
			JLabel mm = new JLabel();
			int size = (int)north.spin.getValue();
			Font s = new Font("宋体", Font.BOLD, size);
			mm.setFont(s);
			mm.setForeground(north.getUserColor);
			mm.setText(north.text.getText());
			center.add(mm);
		}
	}

	// 鼠标按压事件
	@Override
	public void mousePressed(MouseEvent e) {
		// 对数组进行扩容
		if (west.btn1.isSelected() || west.btn2.isSelected()
				|| west.btn3.isSelected() || west.btn4.isSelected()
				|| west.btn5.isSelected()) {
			x1 = Arrays.copyOf(x1, x1.length + 1);
			y1 = Arrays.copyOf(y1, y1.length + 1);
			x2 = Arrays.copyOf(x2, x2.length + 1);
			y2 = Arrays.copyOf(y2, y2.length + 1);
			xycolor = Arrays.copyOf(xycolor, xycolor.length + 1);
			xyshape = Arrays.copyOf(xyshape, xyshape.length + 1);
			fills = Arrays.copyOf(fills, fills.length + 1);
			// 获得起始点坐标
			x1[x1.length - 1] = e.getX();
			y1[y1.length - 1] = e.getY();
			xycolor[xycolor.length - 1] = north.getUserColor;
			xyshape[xyshape.length - 1] = getUserShape();
			fills[fills.length - 1] = north.isfill;
			// 界面最下面的状态信息
			startx = e.getX();
			starty = e.getY();
		}
	}

	// 鼠标松开事件
	@Override
	public void mouseReleased(MouseEvent e) {
		// 设置结束点坐标
		if (west.btn1.isSelected() || west.btn2.isSelected()
				|| west.btn3.isSelected() || west.btn4.isSelected()
				|| west.btn5.isSelected()) {
			x2[x2.length - 1] = e.getX();
			y2[y2.length - 1] = e.getY();
			// repaint();
		}
		endx = e.getX();
		endy = e.getY();
		south.coordinate.setText("Released x1=" + startx + " y1=" + starty + " x2=" + endx + " y2=" + endy);
	}

	// 鼠标拖动事件（实现拖动显示线条的效果）
	@Override
	public void mouseDragged(MouseEvent e) {
		if (west.btn1.isSelected() || west.btn2.isSelected()
				|| west.btn3.isSelected() || west.btn4.isSelected()
				|| west.btn5.isSelected()) {
			x2[x2.length - 1] = e.getX();
			y2[y2.length - 1] = e.getY();
			repaint();
		}
	}
	
	public int getUserShape() {
		if (west.btn1.isSelected()) {
			return 1;
		} else if (west.btn2.isSelected()) {
			return 2;
		} else if (west.btn3.isSelected()) {
			return 3;
		} else if (west.btn4.isSelected()) {
			return 4;
		} else if (west.btn5.isSelected()) {
			return 5;
		} else {
			return 0;
		}
	}

	public void choiceShape(Graphics g, int i, int way, boolean fill) {
		if (way == 1) {
			g.drawLine(x1[i], y1[i], x2[i], y2[i]);
		} else if (way == 2 && !fill) {
			g.drawOval(x1[i], y1[i], (x2[i] - x1[i]), (x2[i] - x1[i]));
		} else if (way == 3 && !fill) {
			g.drawRect(x1[i], y1[i], (x2[i] - x1[i]), (x2[i] - x1[i]));
		} else if (way == 4 && !fill) {
			g.drawOval(x1[i], y1[i], (x2[i] - x1[i]), (y2[i] - y1[i]));
		} else if (way == 5 && !fill) {
			g.drawRect(x1[i], y1[i], (x2[i] - x1[i]), (y2[i] - y1[i]));
		} else if (way == 2 && fill) {
			g.fillOval(x1[i], y1[i], (x2[i] - x1[i]), (x2[i] - x1[i]));
		} else if (way == 3 && fill) {
			g.fillRect(x1[i], y1[i], (x2[i] - x1[i]), (x2[i] - x1[i]));
		} else if (way == 4 && fill) {
			g.fillOval(x1[i], y1[i], (x2[i] - x1[i]), (y2[i] - y1[i]));
		} else if (way == 5 && fill) {
			g.fillRect(x1[i], y1[i], (x2[i] - x1[i]), (y2[i] - y1[i]));
		} else if (way == 0) {
			return;
		}
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		center.setBackground(north.getBackColor);
	}
}