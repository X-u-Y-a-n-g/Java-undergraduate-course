package HuaBan;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class SouthP extends JPanel{
	public JLabel coordinate;
	public SouthP(){
		coordinate = new JLabel();
		this.setLayout(new GridLayout(1, 2));
		this.add(coordinate, BorderLayout.EAST);
	}
}