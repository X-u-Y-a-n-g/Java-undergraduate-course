package HuaBan;

import javax.swing.*;
import java.awt.*;

//主界面
public class MainP {
	JFrame f = new JFrame();
	public CenterP p = new CenterP();
	private JMenu[] menus = { new JMenu("File"), new JMenu("Edit"),
			new JMenu("Help") };
	private JMenuItem[] items = { new JMenuItem("New"), new JMenuItem("Find"),
			new JMenuItem("Welcome"), new JMenuItem("Open"),
			new JMenuItem("Delete"), new JMenuItem("Search"),
			new JMenuItem("Close"), new JMenuItem("Add"), new JMenuItem("Show") };

	
	public MainP() {
		// 主面板
		paintSet(f);
		f.add(p, BorderLayout.CENTER);
	}

	public static void main(String[] args) {
		MainP paint = new MainP();
	}
	
	public JMenuBar createMenu(JMenu[] menus, JMenuItem[] items) {
		for (int i = 0; i < items.length; i++) {
			menus[i % 3].add(items[i]);
		}
		JMenuBar mb = new JMenuBar();
		for (JMenu jm : menus)
			mb.add(jm);
		return mb;
	}

	public void paintSet(JFrame frame) {
		frame.setJMenuBar(createMenu(menus, items));
		frame.setSize(1000, 800);
		frame.setTitle("图画工具--draw picture");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
}